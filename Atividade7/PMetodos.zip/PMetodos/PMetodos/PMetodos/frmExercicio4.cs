﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQtdeNum_Click(object sender, EventArgs e)
        {
            int cont = 0, tam = rtxtTexto.Text.Length;

            if (rtxtTexto.Text == "")
                MessageBox.Show("Não foi escrito nada!");
            else
            {
                for (var i = 0; i < tam; i++)
                {
                    if (Char.IsNumber(rtxtTexto.Text, i))
                        cont++;
                }

                MessageBox.Show("Tem " + cont + " caracteres numéricos neste texto");
            }
        }

        private void btnLocalizaEspaco_Click(object sender, EventArgs e)
        {
            int tam = 0;

            if (rtxtTexto.Text == "")
                MessageBox.Show("Não foi escrito nada!");
            else
            {
                while (tam != rtxtTexto.Text.Length)
                {
                    if (Char.IsWhiteSpace(rtxtTexto.Text, tam))
                    {
                        MessageBox.Show("Caractere branco encontrado na posição " + (tam + 1) + "!");

                        tam = rtxtTexto.Text.Length;
                    }
                    else
                        tam++;
                }
            }
        }

        private void btnQtdeAlfabeticos_Click(object sender, EventArgs e)
        {
            string texto = rtxtTexto.Text;
            int cont = 0;

            if (rtxtTexto.Text == "")
                MessageBox.Show("Não foi escrito nada!");
            else
            {
                foreach (var caracter in texto)
                {
                    if (Char.IsLetter(caracter))
                        cont++;
                }
                MessageBox.Show("Tem " + cont + " caracteres alfabéticos no texto");
            }
        }
    }
}
