﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int valorMinimo, valorMaximo, sorteado;
            Random sorteio = new Random();

            if (int.TryParse(txtValorMinimo.Text, out valorMinimo) && int.TryParse(txtValorMaximo.Text, out valorMaximo) && (valorMinimo < valorMaximo))
            {
                sorteado = sorteio.Next(valorMinimo, valorMaximo);

                MessageBox.Show("Número sorteado: " + sorteado);
            }
            else
            {
                MessageBox.Show("Escreva um número válido!");
                txtValorMinimo.Clear();
                txtValorMaximo.Clear();
                txtValorMinimo.Focus();
            }
        }
    }
}
