﻿namespace PMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValorMinimo = new System.Windows.Forms.Label();
            this.lblValorMaximo = new System.Windows.Forms.Label();
            this.txtValorMinimo = new System.Windows.Forms.TextBox();
            this.txtValorMaximo = new System.Windows.Forms.TextBox();
            this.btnSortear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblValorMinimo
            // 
            this.lblValorMinimo.AutoSize = true;
            this.lblValorMinimo.Font = new System.Drawing.Font("Constantia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorMinimo.Location = new System.Drawing.Point(178, 64);
            this.lblValorMinimo.Name = "lblValorMinimo";
            this.lblValorMinimo.Size = new System.Drawing.Size(110, 19);
            this.lblValorMinimo.TabIndex = 0;
            this.lblValorMinimo.Text = "Valor Mínimo:";
            // 
            // lblValorMaximo
            // 
            this.lblValorMaximo.AutoSize = true;
            this.lblValorMaximo.Font = new System.Drawing.Font("Constantia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorMaximo.Location = new System.Drawing.Point(178, 113);
            this.lblValorMaximo.Name = "lblValorMaximo";
            this.lblValorMaximo.Size = new System.Drawing.Size(112, 19);
            this.lblValorMaximo.TabIndex = 1;
            this.lblValorMaximo.Text = "Valor Máximo:";
            // 
            // txtValorMinimo
            // 
            this.txtValorMinimo.Font = new System.Drawing.Font("Constantia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorMinimo.Location = new System.Drawing.Point(294, 61);
            this.txtValorMinimo.Name = "txtValorMinimo";
            this.txtValorMinimo.Size = new System.Drawing.Size(228, 27);
            this.txtValorMinimo.TabIndex = 2;
            // 
            // txtValorMaximo
            // 
            this.txtValorMaximo.Font = new System.Drawing.Font("Constantia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorMaximo.Location = new System.Drawing.Point(294, 113);
            this.txtValorMaximo.Name = "txtValorMaximo";
            this.txtValorMaximo.Size = new System.Drawing.Size(228, 27);
            this.txtValorMaximo.TabIndex = 3;
            // 
            // btnSortear
            // 
            this.btnSortear.Font = new System.Drawing.Font("Constantia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSortear.Location = new System.Drawing.Point(268, 187);
            this.btnSortear.Name = "btnSortear";
            this.btnSortear.Size = new System.Drawing.Size(146, 63);
            this.btnSortear.TabIndex = 4;
            this.btnSortear.Text = "Sortear";
            this.btnSortear.UseVisualStyleBackColor = true;
            this.btnSortear.Click += new System.EventHandler(this.btnSortear_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(664, 283);
            this.Controls.Add(this.btnSortear);
            this.Controls.Add(this.txtValorMaximo);
            this.Controls.Add(this.txtValorMinimo);
            this.Controls.Add(this.lblValorMaximo);
            this.Controls.Add(this.lblValorMinimo);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValorMinimo;
        private System.Windows.Forms.Label lblValorMaximo;
        private System.Windows.Forms.TextBox txtValorMinimo;
        private System.Windows.Forms.TextBox txtValorMaximo;
        private System.Windows.Forms.Button btnSortear;
    }
}