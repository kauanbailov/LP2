﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTesteClasses
{
    class Horista: Empregado
    {
        // Não pode herdar mais de uma classe, pois não existe herança múltipla

        // Escreva "prop" e aperte TAB 2x para gerar a estrutura das propriedades
        public double SalarioHora { get; set; }
        public double NumeroHora { get; set; }
        public int DiasFalta { get; set; }

        public override double SalarioBruto()
        {
            return SalarioHora * NumeroHora;
        }

        public override int TempoTrabalho()
        {
            // O método retorna um tipo span
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days - DiasFalta);
        }
    }
}
